require('dotenv').config();
const express = require('express');
const cors = require('cors');
const db = require('./src/database/db');
const entradaRoutes = require('./src/routes/entrada.routes');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/entradas', entradaRoutes);

const PORT = process.env.PORT || 3003;

db.sync().then(() => {
  console.log('🎟️ DB conectada y sincronizada');
  app.listen(PORT, () => console.log(`🎬 ms-entradas corriendo en puerto ${PORT}`));
}).catch(err => {
  console.error('❌ Error al conectar DB:', err);
});
