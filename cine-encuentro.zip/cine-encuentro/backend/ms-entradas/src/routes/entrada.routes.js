const express = require('express');
const router = express.Router();
const controller = require('../controllers/entrada.controller');

router.get('/', controller.listarEntradas);
router.post('/', controller.crearEntrada);

module.exports = router;
