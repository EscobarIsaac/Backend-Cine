const Entrada = require('../models/entrada.model');

exports.crearEntrada = async (req, res) => {
  try {
    const entrada = await Entrada.create(req.body);
    res.status(201).json(entrada);
  } catch (err) {
    res.status(500).json({ error: 'Error al crear entrada' });
  }
};

exports.listarEntradas = async (req, res) => {
  try {
    const entradas = await Entrada.findAll();
    res.json(entradas);
  } catch (err) {
    res.status(500).json({ error: 'Error al listar entradas' });
  }
};
