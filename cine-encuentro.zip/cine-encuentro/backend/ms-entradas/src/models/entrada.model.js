const { DataTypes } = require('sequelize');
const db = require('../database/db');

const Entrada = db.define('Entrada', {
  usuarioId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  peliculaId: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  asiento: {
    type: DataTypes.STRING,
    allowNull: false
  },
  hora: {
    type: DataTypes.STRING,
    allowNull: false
  },
  fecha: {
    type: DataTypes.DATEONLY,
    allowNull: false
  }
});

module.exports = Entrada;
