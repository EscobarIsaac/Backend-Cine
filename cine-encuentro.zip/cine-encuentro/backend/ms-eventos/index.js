require('dotenv').config();
const app = require('./src/app');
const sequelize = require('./src/database/db');

const PORT = process.env.PORT || 3002;

async function start() {
  try {
    await sequelize.sync({ force: false });
    app.listen(PORT, () => console.log(`🚀 ms-eventos corriendo en puerto ${PORT}`));
  } catch (error) {
    console.error('❌ Error al iniciar ms-eventos:', error);
  }
}

start();
