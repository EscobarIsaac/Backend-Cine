const { sendMessage } = require('../messaging/rabbitmq');

// Simulación de una base de datos (puedes reemplazarlo por Sequelize)
let peliculas = [];

const crearPelicula = async (req, res) => {
  const { titulo, descripcion } = req.body;

  if (!titulo || !descripcion) {
    return res.status(400).json({ error: 'Faltan datos' });
  }

  const nuevaPelicula = { id: peliculas.length + 1, titulo, descripcion };
  peliculas.push(nuevaPelicula);

  // Enviar a RabbitMQ
  await sendMessage('evento.cola', {
    tipo: 'pelicula_creada',
    payload: nuevaPelicula
  });

  res.status(201).json({ mensaje: 'Película creada', data: nuevaPelicula });
};

const listarPeliculas = (req, res) => {
  res.json(peliculas);
};

module.exports = {
  crearPelicula,
  listarPeliculas
};
