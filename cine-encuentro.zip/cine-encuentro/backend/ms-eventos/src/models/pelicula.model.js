const { DataTypes } = require('sequelize');
const sequelize = require('../database/db');

const Pelicula = sequelize.define('Pelicula', {
  titulo: { type: DataTypes.STRING, allowNull: false },
  genero: { type: DataTypes.STRING, allowNull: false },
  duracion: { type: DataTypes.INTEGER, allowNull: false },
  clasificacion: { type: DataTypes.STRING, allowNull: false }
});

module.exports = Pelicula;
