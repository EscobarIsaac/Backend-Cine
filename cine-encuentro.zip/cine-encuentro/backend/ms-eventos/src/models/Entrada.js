const { DataTypes } = require('sequelize');
const sequelize = require('../database/db');

const Entrada = sequelize.define('Entrada', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true
  },
  evento: {
    type: DataTypes.STRING,
    allowNull: false
  },
  cantidad: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  comprador: {
    type: DataTypes.STRING,
    allowNull: false
  }
});

module.exports = Entrada;
