const express = require('express');
const { crearPelicula, listarPeliculas } = require('../controllers/evento.controller');
const router = express.Router();

router.post('/peliculas', crearPelicula);
router.get('/peliculas', listarPeliculas);

module.exports = router;
