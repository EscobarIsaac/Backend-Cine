const express = require('express');
const { crearPelicula, listarPeliculas } = require('../controllers/evento.controller');
const { sendMessage } = require('../messaging/rabbitmq');
const router = express.Router();

router.post('/peliculas', crearPelicula);
router.get('/peliculas', listarPeliculas);

// Ruta para probar envío a RabbitMQ
router.post('/test-rabbit', async (req, res) => {
  try {
    const mensaje = req.body.mensaje || 'Mensaje de prueba desde ms-eventos';
    await sendMessage('evento.cola', mensaje);
    res.status(200).json({ mensaje: '✅ Mensaje enviado a RabbitMQ: evento.cola' });
  } catch (error) {
    console.error('❌ Error al enviar mensaje:', error);
    res.status(500).json({ error: 'Error enviando mensaje a RabbitMQ' });
  }
});

module.exports = router;
