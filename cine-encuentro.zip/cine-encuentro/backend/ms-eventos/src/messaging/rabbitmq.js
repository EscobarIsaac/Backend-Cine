// ✅ ms-eventos/src/messaging/rabbitmq.js
const amqp = require('amqplib');

let channel;

async function connectRabbitMQ() {
  try {
    const connection = await amqp.connect('amqp://admin:admin@rabbitmq:5672');
    channel = await connection.createChannel();
    console.log('✅ Conectado a RabbitMQ desde ms-eventos');
  } catch (error) {
    console.error('❌ Error al conectar a RabbitMQ:', error);
  }
}

async function sendMessage(queue, message) {
  if (!channel) {
    await connectRabbitMQ();
  }
  await channel.assertQueue(queue, { durable: true });
  channel.sendToQueue(queue, Buffer.from(JSON.stringify({ mensaje: message })));
  console.log(`📤 Mensaje enviado a la cola [${queue}]:`, message);
}

module.exports = { connectRabbitMQ, sendMessage };
