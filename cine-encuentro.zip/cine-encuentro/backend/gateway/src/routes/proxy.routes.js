const express = require('express');
const router = express.Router();
const axios = require('axios');
const { verifyToken } = require('../middlewares/auth.middleware');

// Ejemplo: redirigir a ms-usuarios
router.get('/usuarios', verifyToken, async (req, res) => {
  try {
    const response = await axios.get('http://localhost:3001/usuarios');
    res.json(response.data);
  } catch (err) {
    res.status(500).json({ error: 'Error al conectar con ms-usuarios' });
  }
});

module.exports = router;
