const express = require('express');
const cors = require('cors');
const proxyRoutes = require('./routes/proxy.routes');

const app = express();

app.use(cors());
app.use(express.json());

// Rutas
app.use('/api', proxyRoutes);

module.exports = app;
