# Cine Encuentro - Backend

Arquitectura de microservicios con Node.js y RabbitMQ.

## Levantar todo

1. Instalar dependencias:
   ```bash
   cd gateway && npm install
   cd ../ms-usuarios && npm install
   # ... y así en cada carpeta de microservicio
   cd ..
