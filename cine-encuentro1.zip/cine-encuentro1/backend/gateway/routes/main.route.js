import { Router } from 'express';
const router = Router();

router.get('/ping', (req, res) => {
  res.json({ mensaje: '🏓 Pong desde /api/ping' });
});

export default router;
