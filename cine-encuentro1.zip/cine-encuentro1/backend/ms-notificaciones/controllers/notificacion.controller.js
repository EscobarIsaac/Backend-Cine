exports.enviarNotificacion = (req, res) => {
  const { mensaje, destino } = req.body;
  // Simular envío de notificación
  console.log(`🔔 Notificación a ${destino}: ${mensaje}`);
  res.json({ estado: 'Enviado' });
};
