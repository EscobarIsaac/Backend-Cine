
const express = require('express');
const router = express.Router();
const { crearEvento } = require('../controllers/evento.controller');

router.post('/crear', crearEvento);

module.exports = router;
