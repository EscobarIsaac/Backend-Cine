
const express = require('express');
const cors = require('cors');
const eventoRoutes = require('./routes/evento.routes');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/eventos', eventoRoutes);

module.exports = app;
