
const { sendMessage } = require('../messaging/rabbitmq');

exports.crearEvento = async (req, res) => {
  const evento = req.body;
  console.log('🎥 Evento recibido:', evento);

  // Enviar a RabbitMQ
  await sendMessage('evento.cola', evento);

  res.status(201).json({ message: 'Evento creado y enviado a la cola' });
};
