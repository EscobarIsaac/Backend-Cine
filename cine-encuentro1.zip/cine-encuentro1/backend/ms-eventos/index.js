
require('dotenv').config();
const app = require('./app');
const { connectRabbitMQ } = require('./messaging/rabbitmq');

const PORT = process.env.PORT || 3002;

async function start() {
  await connectRabbitMQ();
  app.listen(PORT, () => {
    console.log(`🎬 ms-eventos corriendo en el puerto ${PORT}`);
  });
}

start();
