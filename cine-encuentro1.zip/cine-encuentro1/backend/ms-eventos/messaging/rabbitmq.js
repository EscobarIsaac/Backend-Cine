
const amqp = require('amqplib');

let channel;

async function connectRabbitMQ() {
  try {
    const connection = await amqp.connect(process.env.RABBITMQ_URL || 'amqp://admin:admin@localhost:5672');
    channel = await connection.createChannel();
    console.log('✅ Conectado a RabbitMQ');
  } catch (error) {
    console.error('❌ Error conectando a RabbitMQ:', error);
  }
}

async function sendMessage(queue, message) {
  if (!channel) await connectRabbitMQ();
  await channel.assertQueue(queue, { durable: true });
  channel.sendToQueue(queue, Buffer.from(JSON.stringify(message)));
  console.log(`📤 Mensaje enviado a la cola [${queue}]`);
}

module.exports = { connectRabbitMQ, sendMessage };
