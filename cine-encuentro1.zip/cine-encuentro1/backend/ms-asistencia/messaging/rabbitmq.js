// messaging/rabbitmq.js - archivo base
