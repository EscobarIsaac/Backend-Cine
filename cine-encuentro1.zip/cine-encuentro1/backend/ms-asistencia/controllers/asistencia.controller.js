let registros = [];

exports.registrarAsistencia = (req, res) => {
  const { eventoId, usuario } = req.body;
  registros.push({ eventoId, usuario, hora: new Date().toISOString() });
  res.status(201).json({ mensaje: 'Asistencia registrada' });
};

exports.listarAsistencias = (req, res) => {
  res.json(registros);
};
