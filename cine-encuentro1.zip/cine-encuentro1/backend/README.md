# Cine Encuentro - Backend

Este proyecto contiene todos los microservicios del sistema Cine Encuentro.

## Microservicios

- Gateway
- ms-usuarios
- ms-eventos
- ms-entradas
- ms-notificaciones
- ms-asistencia

## RabbitMQ

Cola compartida: `evento.cola`  
Con usuario: `admin`  
Contraseña: `admin`  
Puerto: `5672` y panel en `15672`

## Comandos

1. Instalar dependencias localmente:
```bash
npm install
```

2. Ejecutar todo con Docker:
```bash
docker-compose up --build
```

3. Acceder:
- Gateway: http://localhost:3000
- RabbitMQ panel: http://localhost:15672