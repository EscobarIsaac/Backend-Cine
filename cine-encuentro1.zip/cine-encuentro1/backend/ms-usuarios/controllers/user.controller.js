const jwt = require('jsonwebtoken');

const usuarios = [
  { id: 1, nombre: 'admin', rol: 'admin', password: 'admin123' },
  { id: 2, nombre: 'cliente', rol: 'cliente', password: 'cliente123' }
];

exports.login = (req, res) => {
  const { nombre, password } = req.body;
  const user = usuarios.find(u => u.nombre === nombre && u.password === password);

  if (!user) return res.status(401).json({ mensaje: 'Credenciales incorrectas' });

  const token = jwt.sign({ id: user.id, rol: user.rol }, process.env.JWT_SECRET, { expiresIn: '1h' });
  res.json({ token });
};
