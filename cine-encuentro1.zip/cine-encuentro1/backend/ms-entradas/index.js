
require('dotenv').config();
const app = require('./app');
const { connectRabbitMQ } = require('./messaging/rabbitmq');

const PORT = process.env.PORT || 3003;

async function start() {
  await connectRabbitMQ();
  app.listen(PORT, () => {
    console.log(`🎟️ ms-entradas corriendo en el puerto ${PORT}`);
  });
}

start();
