
const express = require('express');
const cors = require('cors');
const entradaRoutes = require('./routes/entrada.routes');

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/entradas', entradaRoutes);

module.exports = app;
