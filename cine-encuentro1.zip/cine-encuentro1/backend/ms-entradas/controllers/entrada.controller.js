let entradas = [];

exports.crearEntrada = (req, res) => {
  const { eventoId, cliente } = req.body;
  const nueva = { id: entradas.length + 1, eventoId, cliente };
  entradas.push(nueva);
  res.status(201).json(nueva);
};

exports.listarEntradas = (req, res) => {
  res.json(entradas);
};
