// routes/entrada.route.js - archivo base
