
const express = require('express');
const router = express.Router();
const { obtenerEntradas } = require('../controllers/entrada.controller');

router.get('/', obtenerEntradas);

module.exports = router;
