
const amqp = require('amqplib');

async function connectRabbitMQ() {
  try {
    const connection = await amqp.connect(process.env.RABBITMQ_URL || 'amqp://admin:admin@localhost:5672');
    const channel = await connection.createChannel();
    const queue = 'evento.cola';

    await channel.assertQueue(queue, { durable: true });
    console.log('📥 Escuchando mensajes de la cola:', queue);

    channel.consume(queue, (msg) => {
      if (msg !== null) {
        const contenido = JSON.parse(msg.content.toString());
        console.log('🎫 Entrada recibida de la cola:', contenido);
        channel.ack(msg);
      }
    });
  } catch (error) {
    console.error('❌ Error conectando a RabbitMQ:', error);
  }
}

module.exports = { connectRabbitMQ };
